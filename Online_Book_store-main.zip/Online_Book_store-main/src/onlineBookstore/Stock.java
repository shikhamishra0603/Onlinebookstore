package onlineBookstore;

public class Stock {

}
